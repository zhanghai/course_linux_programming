//
// Copyright (c) 2015 zh
// All rights reserved.
//

#ifndef ZHSH_PARSER_H
#define ZHSH_PARSER_H

#include "line_syntax.h"

cmd_list_t *parse_line(const char *line);

#endif //ZHSH_PARSER_H
