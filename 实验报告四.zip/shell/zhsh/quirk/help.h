//
// Copyright (c) 2015 zh
// All rights reserved.
//

#ifndef ZHSH_HELP_H
#define ZHSH_HELP_H

int help();

#endif //ZHSH_HELP_H
