//
// Copyright (c) 2015 zh
// All rights reserved.
//

#ifndef ZHSH_ENV_H
#define ZHSH_ENV_H

int env();

#endif //ZHSH_ENV_H
