//
// Copyright (c) 2015 zh
// All rights reserved.
//

#ifndef ZHSH_LS_H
#define ZHSH_LS_H

int ls(int argc, char *argv[]);

#endif //ZHSH_LS_H
