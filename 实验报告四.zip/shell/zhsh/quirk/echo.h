//
// Copyright (c) 2015 zh
// All rights reserved.
//

#ifndef ZHSH_ECHO_H
#define ZHSH_ECHO_H

int echo(char **argv);

#endif //ZHSH_ECHO_H
