/* 声明用户提示 */
#define PROMPT1 "请输入x的值："
#define PROMPT2 "请输入y的值："
