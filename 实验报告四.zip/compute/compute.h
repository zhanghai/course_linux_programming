/* compute函数的声明原形 */
double compute(double, double);
