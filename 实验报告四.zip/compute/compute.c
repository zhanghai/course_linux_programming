#include <math.h>
#include <stdio.h>
#include "compute.h"
double compute(double x, double y)
{
	return (pow ((double)x, (double)y));
}
