/* input函数的声明原形 */
double input(char *);
